﻿namespace GolCheckApi.Models.DbSettings
{
    public class IspanyaDatabaseSettings
    {
        public string IspanyaConnectionString { get; set; } = null!;

        public string IspanyaDatabaseName { get; set; } = null!;

        public string IspanyaCollectionName { get; set; } = null!;
    }
}
