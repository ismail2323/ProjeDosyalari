﻿namespace GolCheckApi.Models.DbSettings
{
    public class SerieADatabaseSettings
    {
        public string SerieAConnectionString { get; set; } = null!;

        public string SerieADatabaseName { get; set; } = null!;

        public string SerieACollectionName { get; set; } = null!;
    }
}
